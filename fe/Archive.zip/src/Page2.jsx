import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import "./Pages.scss";
import net from "./assets/mailnet.png";
import rocket from "./assets/rocket.png";
import axios from "axios";
import { useEffect, useRef } from "react";

const Page2 = () => {




  const hasRun = useRef(false);

  // useEffect hook
  useEffect(() => {
    // Check if the effect has already been run


    if (!hasRun.current) {
      const url = new URL(window.location.href);
      const authorizationCode = url.searchParams.get("code");
      const authorizationScope = url.searchParams.get("scope");

      if (authorizationCode && authorizationScope) {
        fetchEmails(authorizationCode, authorizationScope);
      }

      // Mark as run
      hasRun.current = true;
    }
  }, []);


 
    const fetchEmails = async (code, scope) => {
      try {
        // Fetch inbox emails
        const tokenResponse = await axios.get(`http://192.168.1.8:5000/auth/google/callback?code=${code}&scope=${scope}`);
        console.log(tokenResponse);
        const inboxResponse = await axios.get('http://192.168.1.8:5000/api/gmail/inbox');
        console.log('Inbox Emails:', inboxResponse.data);

        // Fetch sent emails
        const sentResponse = await axios.get('http://192.168.1.8:5000/api/gmail/sent');
        console.log('Sent Emails:', sentResponse.data);
      } catch (error) {
        console.error('Error fetching emails:', error);
      }
    };

  

  return (

  <div className="main">
    <div className="page1">
      <div className="upper-p"></div>
      <div className="lower-p"></div>
    </div>
    </div>
  );
};

export default Page2;
